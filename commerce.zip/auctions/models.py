from calendar import c
from django.contrib.auth.models import AbstractUser
from django.db import models

"""
用户模型
"""
class User(AbstractUser):
    pass

class auctions(models.Model):
    title=models.CharField(max_length=80)
    description=models.CharField(max_length=80)
    startbid = models.CharField(max_length=80)
    category= models.CharField(max_length=80)
    image=models.CharField(max_length=512)
    createTime = models.CharField(max_length=80)
    createby = models.CharField(max_length=80)
    status = models.CharField(max_length=80)

class bids(models.Model):
    title=models.CharField( max_length=80)
    nowbid = models.CharField(max_length=80)
    createby = models.CharField( max_length=80)


class wathclist(models.Model):
    user =  models.CharField(max_length=80)
    title=models.CharField(max_length=80)
    description=models.CharField( max_length=80)
    startbid = models.CharField(max_length=80)
    category= models.CharField( max_length=80)
    image=models.CharField(max_length=512)
    createTime = models.CharField(max_length=80)
    
class comments(models.Model):
    title = models.CharField(max_length=80)
    name = models.CharField(max_length=80)
    content = models.CharField(max_length=1500)